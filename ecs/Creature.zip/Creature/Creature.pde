//TJ Bowen | 24 Feb 2026 | Creature
void setup() {
  size(1000,1000);
  background(#C7D6AD);
  noCursor();
}

void draw() {
  background(#C7D6AD);
  println(mouseX,mouseY);
  drawCreature(100,100);
  drawCreature(mouseX,mouseY);
}

void drawCreature(int x, int y) {
  strokeWeight(2);
  stroke(0,0,0);
  fill(#FF8EBF);
  triangle(x-35,y-35,x-40,y-65,x-20,y-45);//left ear
  triangle(x+35,y-35,x+40,y-65,x+20,y-45);//right ear
  rect(x+25,y+50,20,80,15);//leg
  rect(x+50,y+50,20,80,15);//leg
  rect(x+80,y+50,20,80,15);//leg
  rect(x+105,y+50,20,80,15);//leg
  ellipse(x+70,y+40,150,100);//body
  ellipse(x,y,100,100);//head
  fill(#FFFFFF);
  ellipse(x-20,y-15,15,15);//left eye
  ellipse(x+20,y-15,15,15);//right eye
  line(x-23,y-30,x-7,y-20);//eyebrowright
  line(x+7,y-20,x+23,y-30);// eyebrowleft
  fill(#FCBFDA);
  ellipse(x,y+10,40,30);//Nose
  fill(#FF8EBF);
  ellipse(x-8,y+10,10,12);//nostril
  ellipse(x+8,y+10,10,12);//nostril
  line(x-2,y+35,x+25,y+20);//smile
  
  
}

// TJ Bowen | Timer | March 26 2026
import processing.sound.*;
SoundFile alarm;
Button btnStart, btnStop, btnReset;
int totalTime = 10;
int startTime = 0;
int timeLeft = 0;
boolean running = false;

void setup() {
  size(500, 500);
  alarm = new SoundFile (this,"alarm.mp3");
  btnStart = new Button(80, 70, 100, 30, "Start", color(80), color(40));
  btnStop = new Button(420, 70, 100, 30, "Stop", color(80), color(40));
  btnReset = new Button(250, 450, 100, 30, "Reset", color(80), color(40));
  timeLeft = totalTime;
}

void draw() {
  background(#4A5A3F);

  if (running == true) {
    int elapsed = (millis() - startTime)/1000;
    timeLeft = totalTime - elapsed;

    if (timeLeft <= 0) {
      timeLeft = 0;
      running = false;
      //play sound
      alarm.play();
    }
  }
  
  btnStart.display();
  btnStart.hover();
  btnStop.display();
  btnStop.hover();
  btnReset.display();
  btnReset.hover(); 
  fill(180);
  rect(width/2, height/2+20,width-100,200);
  textSize(100);
  fill(60);
  text(timeLeft, width/2, 250);
  //laser.play();
  textSize(30);
  text("By TJ Bowen", width/2, 385);
}

void mousePressed() {
  if(btnStart.over == true) {
    running = true;
    startTime = millis();
  }
  if(btnReset.over == true) {
    running = true;
    startTime = millis();
  }
  if(btnStop.over == true) {
    running = false;
  }
}

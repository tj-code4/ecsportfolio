// TJ Bowen | MiniProject | March 31, 2026

String password = "";
String secret = "1234"; // Change this to your desired password
String status = "ENTER PASSWORD";

void setup() {
  size(500, 500);
  textAlign(CENTER, CENTER);
  textSize(24);
}

void draw() {
  background(200);
  fill(50);
  text(status, width/2, height/2 - 40);
  String masked = "";
  for (int i = 0; i < password.length(); i++) {
    masked += "*";
  }
  
  fill(0);
  text(masked, width/2, height/2 + 20);
  textSize(12);
  fill(100);
  text("Type 4 Numbers and Press ENTER to Guess", width/2, height - 30);
  textSize(24);
}

void keyPressed() {
  if (key == ENTER || key == RETURN) {
    if (password.equals(secret)) {
      status = "CORRECT";
      background(#118300);
    } else {
      status = "INCORRECT";
      background(#CE0700);
      password = ""; 
    }
  } 
  else if (key == BACKSPACE) {
    if (password.length() > 0) {
      password = password.substring(0, password.length() - 1);
    }
  } 
  else if (key != CODED) {
    password += key;
  }
}

//TJ Bowen | Feb 26 2026 | Timeline
void setup() {
  size(950,400);
}
void draw() {
  background(#1C4563);
  drawRef();
  histEvent(700,200,"March 2020", true,"Tom Brady joined the Tampa Bay Buccaneers in March 2020, signing as a free agent, \n leaving the New England Patriots after his 20 year run. His first season with Tampa Bay resulted in a Super Bowl LV victory .");
  histEvent(82,200,"April 2000", true,"April 2000 — Drafted by the New England Patriots,\n 199th overall in the NFL Draft.");
  histEvent(150,300,"February 2002",false,"February 2002 — Wins his first Super Bowl (Super Bowl XXXVI), beginning the Patriots dynasty.");
  histEvent(200,200,"February 2004", true,"February 2004 — Wins his second Super Bowl (XXXVIII), earning another Super Bowl MVP. ");
  histEvent(325,200,"February 2008", true,"February 2008 — Marries Gisele Bündchen. ");
  histEvent(335,300,"September 2008. ", false,"September 2008 — Suffers a major knee injury (torn ACL) in Week 1, ending his season. ");
  histEvent(505,300,"February 2015",false,"February 2015 — Wins Super Bowl XLIX, beating the Seahawks 28-24, which was one of the most dramatic comebacks of his career.");
  histEvent(745,300,"February 2023", false,"February 2023 — Announces retirement from the NFL for good, ending a 23-year career.");
}
void drawRef() {
  textAlign(CENTER);
  textSize(38);
  fill(#DB0B07);
  text("Tom Brady: Timeline", width/2,70);
  textSize(15);
  text("By TJ Bowen", width/2,90);
  strokeWeight(3);
  line(50,250,900,250);
  strokeWeight(1);
  line(50,255,50,245);
  line(900,255,900,245);
  line(475,255,475,245);
  line(262.5,255,262.5,245);
  line(687.5,255,687.5,245);
  fill(#D9D9B2);
  textSize(12);
  text("2000",50,240);
  text("2030",900,240);
  text("2015",475,240);
  text("2007",262.5,270);
  text("2022",687.5,270);
}
void histEvent(int x, int y, String title, boolean top, String detail) {
  if(top == true) {
    line(x,y,x-30,y+50);
  } else {
    line(x,y,x-30,y-50);
  }
  rectMode(CENTER);
  fill(#863231);
  rect(x,y,100,30,7);
  fill(255);
  text(title,x,y+5);
  if(mouseX > x-50 && mouseX < x+50 && mouseY > y-15 && mouseY < y+15) {
    text(detail, width/2, 350);
  }
}

// Etch-a-Sketch | TJ Bowen | March 17 2026
int x, y;
PImage img;

void setup() {
  size(1001, 818);
  background(255);
  x = width/2;
  y = height/2;
  fill(180);
  stroke(0);
img = loadImage("etch.png");
image(img, 0, 0);
}

void draw() {
  stroke(0);
  strokeWeight(2);
}
void clearScreen() {
  background(200);
  image(img, 0, 0, width, height);
  fill(#FFFAFA);
  x = width/2;
  y = height/2;
}

void keyPressed() {
    int step = 5; 

  if (key == 'w' || key == 'W') {
    moveUp(step);
  } else if (key == 's' || key == 'S') {
    moveDown(step);
  } else if (key == 'a' || key == 'A') {
    moveLeft(step);
  } else if (key == 'd' || key == 'D') {
    moveRight(step);
  } 
  
  if (key == ' ') {
    clearScreen();
  }
}
void mouseReleased() {
  saveFrame("Art-######.png");
}
void moveRight(int rep) {
  for (int i=0; i<rep; i++) {
    point(x+i, y);
  }
  x = x + rep;
}

void moveLeft(int rep) {
  for (int i=0; i<rep; i++) {
    point(x-i, y);
  }
  x = x - rep;
}

void moveUp(int rep) {
  for (int i=0; i<rep; i++) {
    point(x, y-i);
  }
  y = y - rep;
}

void moveDown(int rep) {
  for (int i=0; i<rep; i++) {
    point(x, y+i);
  }
  y = y + rep;
}
